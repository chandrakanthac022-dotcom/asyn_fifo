// Code your design here
module async_fifo #(parameter DATA_WIDTH = 8,
                    parameter ADDR_WIDTH = 3)
(
    input wr_clk,
    input rd_clk,
    input wr_rst,
    input rd_rst,
    input wr_en,
    input rd_en,
    input [DATA_WIDTH-1:0] data_in,

    output [DATA_WIDTH-1:0] data_out,
    output full,
    output empty
);

// pointer wires
wire [ADDR_WIDTH:0] wr_bin, wr_gray;
wire [ADDR_WIDTH:0] rd_bin, rd_gray;

wire [ADDR_WIDTH:0] wr_gray_sync;
wire [ADDR_WIDTH:0] rd_gray_sync;


// FIFO memory
  fifo_memory #(DATA_WIDTH, ADDR_WIDTH) mem (
    .wr_clk(wr_clk),
    .rd_clk(rd_clk),
    .wr_en(wr_en),
    .rd_en(rd_en),
    .wr_addr(wr_bin[ADDR_WIDTH-1:0]),
    .rd_addr(rd_bin[ADDR_WIDTH-1:0]),
    .data_in(data_in),
    .data_out(data_out)
);


// write pointer
write_pointer #(ADDR_WIDTH) wptr (
    .wr_clk(wr_clk),
    .wr_rst(wr_rst),
    .wr_en(wr_en),
    .rd_gray_sync(rd_gray_sync),
    .wr_bin(wr_bin),
    .wr_gray(wr_gray),
    .full(full)
);


// read pointer
read_pointer #(ADDR_WIDTH) rptr (
    .rd_clk(rd_clk),
    .rd_rst(rd_rst),
    .rd_en(rd_en),
    .wr_gray_sync(wr_gray_sync),
    .rd_bin(rd_bin),
    .rd_gray(rd_gray),
    .empty(empty)
);

endmodule