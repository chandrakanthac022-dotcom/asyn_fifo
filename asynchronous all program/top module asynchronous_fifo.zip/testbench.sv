// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module async_fifo_tb;

parameter DATA_WIDTH = 8;
parameter ADDR_WIDTH = 3;

reg wr_clk;
reg rd_clk;
reg wr_rst;
reg rd_rst;
reg wr_en;
reg rd_en;

reg [DATA_WIDTH-1:0] data_in;

wire [DATA_WIDTH-1:0] data_out;
wire full;
wire empty;


// Instantiate DUT
async_fifo #(DATA_WIDTH, ADDR_WIDTH) dut (
    .wr_clk(wr_clk),
    .rd_clk(rd_clk),
    .wr_rst(wr_rst),
    .rd_rst(rd_rst),
    .wr_en(wr_en),
    .rd_en(rd_en),
    .data_in(data_in),
    .data_out(data_out),
    .full(full),
    .empty(empty)
);


// Write clock
always #5 wr_clk = ~wr_clk;

// Read clock
always #7 rd_clk = ~rd_clk;


// Waveform dump
initial begin
$dumpfile("async_fifo.vcd");
$dumpvars(0,async_fifo_tb);
end


initial begin

// Initialize signals
wr_clk = 0;
rd_clk = 0;
wr_rst = 1;
rd_rst = 1;
wr_en  = 0;
rd_en  = 0;
data_in = 0;


// Reset
#10 wr_rst = 0;
#10 rd_rst = 0;


// Write data into FIFO
#10 wr_en = 1;

data_in = 8'h11;
#10 data_in = 8'h22;
#10 data_in = 8'h33;
#10 data_in = 8'h44;
#10 data_in = 8'h55;

#10 wr_en = 0;


// Read data from FIFO
#30 rd_en = 1;

#40 rd_en = 0;


// Finish simulation
#50 $finish;

end


// Monitor output
initial begin
$monitor("Time=%0t wr_en=%b rd_en=%b full=%b empty=%b data_out=%h",
         $time, wr_en, rd_en, full, empty, data_out);
end

endmodule