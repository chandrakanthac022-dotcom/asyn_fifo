`timescale 1ns/1ps

module write_pointer_tb;

parameter ADDR_WIDTH = 3;

reg wr_clk;
reg wr_rst;
reg wr_en;
reg full;

wire [ADDR_WIDTH:0] wr_bin;
wire [ADDR_WIDTH:0] wr_gray;

// Instantiate DUT (Device Under Test)
  write_pointer #(ADDR_WIDTH) dut (
    .wr_clk(wr_clk),
    .wr_rst(wr_rst),
    .wr_en(wr_en),
    .full(full),
    .wr_bin(wr_bin),
    .wr_gray(wr_gray)
);

// Clock generation
always #5 wr_clk = ~wr_clk;

initial begin
$dumpfile("dump.vcd");
$dumpvars(0,write_pointer_tb);


// Initialize signals
wr_clk = 0;
wr_rst = 1;
wr_en  = 0;
full   = 0;

// Reset
#10 wr_rst = 0;

// Start writing
#10 wr_en = 1;

// Stop writing
#80 wr_en = 0;

// Simulate FIFO full
#10 full = 1;

// Try writing when full
#20 wr_en = 1;

// End simulation
#50 $finish;

end

// Display output
initial begin
$monitor("Time=%0t wr_en=%b full=%b wr_bin=%b wr_gray=%b",$time, wr_en, full, wr_bin, wr_gray);
end

endmodule