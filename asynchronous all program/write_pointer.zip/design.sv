// Code your design here
module write_pointer #(
    parameter ADDR_WIDTH = 3
)(  
    input wr_clk,
    input wr_rst,
    input wr_en,
    input full,
    output reg [ADDR_WIDTH:0] wr_bin,
    output reg [ADDR_WIDTH:0] wr_gray
  );

wire [ADDR_WIDTH:0] wr_bin_next;
wire [ADDR_WIDTH:0] wr_gray_next;

// Binary increment
assign wr_bin_next = wr_bin + (wr_en & ~full);

// Binary to Gray conversion
assign wr_gray_next = (wr_bin_next >> 1) ^ wr_bin_next;

always @(posedge wr_clk or posedge wr_rst) begin
    if (wr_rst) begin
        wr_bin  <= 0;
        wr_gray <= 0;
    end else begin
        wr_bin  <= wr_bin_next;
        wr_gray <= wr_gray_next;
    end
end
endmodule