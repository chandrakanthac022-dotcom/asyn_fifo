`timescale 1ns/1ps

module read_pointer_tb;

parameter ADDR_WIDTH = 3;

reg rd_clk;
reg rd_rst;
reg rd_en;
reg [ADDR_WIDTH:0] wr_ptr_gray_sync;

wire [ADDR_WIDTH:0] rd_bin;
wire [ADDR_WIDTH:0] rd_gray;
wire empty;

// DUT
read_pointer #(ADDR_WIDTH) dut (
    .rd_clk(rd_clk),
    .rd_rst(rd_rst),
    .rd_en(rd_en),
    .wr_ptr_gray_sync(wr_ptr_gray_sync),
    .rd_bin(rd_bin),
    .rd_gray(rd_gray),
    .empty(empty)
);

// Clock generation
always #5 rd_clk = ~rd_clk;

// Waveform dump
initial begin
    $dumpfile("read_pointer.vcd");
    $dumpvars(0, read_pointer_tb);
end

initial begin

// Initialization
rd_clk = 0;
rd_rst = 1;
rd_en  = 0;
wr_ptr_gray_sync = 0;

// Reset
#10 rd_rst = 0;

// Simulate write side producing data
#10 wr_ptr_gray_sync = 4'b0001;

// Start reading
#10 rd_en = 1;

// Change write pointer again
#40 wr_ptr_gray_sync = 4'b0011;

// Stop reading
#40 rd_en = 0;

#50 $finish;


end

endmodule