// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module write_pointer_tb;

parameter ADDR_WIDTH = 3;

reg wr_clk;
reg wr_rst;
reg wr_en;
reg [ADDR_WIDTH:0] rd_gray_sync;

wire [ADDR_WIDTH:0] wr_bin;
wire [ADDR_WIDTH:0] wr_gray;
wire full;

// Instantiate DUT
write_pointer #(ADDR_WIDTH) dut (
    .wr_clk(wr_clk),
    .wr_rst(wr_rst),
    .wr_en(wr_en),
    .rd_gray_sync(rd_gray_sync),
    .wr_bin(wr_bin),
    .wr_gray(wr_gray),
    .full(full)
);

// Clock generation
always #5 wr_clk = ~wr_clk;

// Waveform dump
initial begin
  $dumpfile("dump.vcd");
    $dumpvars(0, write_pointer_tb);
end

initial begin

// Initialize signals
wr_clk = 0;
wr_rst = 1;
wr_en  = 0;
rd_gray_sync = 0;

// Reset release
#10 wr_rst = 0;

// Start writing
#10 wr_en = 1;

// Simulate read pointer not moving
rd_gray_sync = 4'b0000;

// Continue writing to fill FIFO
#40;

// Stop writing
wr_en = 0;

// End simulation
#50 $finish;

end


// Monitor signals
initial begin
$monitor("Time=%0t wr_en=%b full=%b wr_bin=%b wr_gray=%b",
          $time, wr_en, full, wr_bin, wr_gray);
end

endmodule