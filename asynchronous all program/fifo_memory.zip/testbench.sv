// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module fifo_memory_tb;

parameter DATA_WIDTH = 8;
parameter ADDR_WIDTH = 3;

reg wr_clk;
reg rd_clk;
reg wr_en;
reg rd_en;
reg [ADDR_WIDTH-1:0] wr_addr;
reg [ADDR_WIDTH-1:0] rd_addr;
reg [DATA_WIDTH-1:0] data_in;

wire [DATA_WIDTH-1:0] data_out;

  // Instantiate DUT
  fifo_memory #(DATA_WIDTH, ADDR_WIDTH) dut (
      .wr_clk(wr_clk),
      .rd_clk(rd_clk),
      .wr_en(wr_en),
      .rd_en(rd_en),
      .wr_addr(wr_addr),
      .rd_addr(rd_addr),
      .data_in(data_in),
      .data_out(data_out)
  );

  // Clock generation
  always #5 wr_clk = ~wr_clk;
  always #7 rd_clk = ~rd_clk;


  // Dump waveform
  initial begin
      $dumpfile("fifo_memory.vcd");
      $dumpvars(0,fifo_memory_tb);
  end


  initial begin

  // Initialize
  wr_clk = 0;
  rd_clk = 0;
  wr_en = 0;
  rd_en = 0;
  wr_addr = 0;
  rd_addr = 0;
  data_in = 0;

  // Write data into FIFO
  #10 wr_en = 1;
  data_in = 8'hA1; wr_addr = 3'b000;

  #10 data_in = 8'hB2; wr_addr = 3'b001;

  #10 data_in = 8'hC3; wr_addr = 3'b010;

  #10 wr_en = 0;


  // Read data from FIFO
  #20 rd_en = 1;
  rd_addr = 3'b000;

  #10 rd_addr = 3'b001;

  #10 rd_addr = 3'b010;

  #20 rd_en = 0;


  // Finish simulation
  #30 $finish;

  end


  // Monitor output
  initial begin
  $monitor("Time=%0t wr_en=%b rd_en=%b wr_addr=%b rd_addr=%b data_in=%h data_out=%h",
          $time, wr_en, rd_en, wr_addr, rd_addr, data_in, data_out);
  end

  endmodule