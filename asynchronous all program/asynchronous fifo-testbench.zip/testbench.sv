`timescale 1ns/1ps

module async_fifo_testbench;

parameter DATA_WIDTH = 8;
parameter ADDR_WIDTH = 3;

// DUT signals
reg wr_clk, rd_clk;
reg wr_rst, rd_rst;
reg wr_en, rd_en;
reg [DATA_WIDTH-1:0] data_in;

wire [DATA_WIDTH-1:0] data_out;
wire full, empty;

// DUT instantiation
async_fifo #(DATA_WIDTH, ADDR_WIDTH) dut(
    .wr_clk(wr_clk),
    .rd_clk(rd_clk),
    .wr_rst(wr_rst),
    .rd_rst(rd_rst),
    .wr_en(wr_en),
    .rd_en(rd_en),
    .data_in(data_in),
    .data_out(data_out),
    .full(full),
    .empty(empty)
);

// Clock generation
always #5 wr_clk = ~wr_clk;   // 10ns period
always #7 rd_clk = ~rd_clk;   // 14ns period

// VCD dump
initial begin
    $dumpfile("async_fifo.vcd");
    $dumpvars(0, async_fifo_tb);
end

//--------------------------------------------------
// MAIN TEST
//--------------------------------------------------
initial begin
    // Initialize
    wr_clk = 0;
    rd_clk = 0;
    wr_rst = 1;
    rd_rst = 1;
    wr_en  = 0;
    rd_en  = 0;
    data_in = 0;

    // Apply reset
    #20;
    wr_rst = 0;
    rd_rst = 0;

    //--------------------------------------------------
    // WRITE OPERATION (SYNC WITH wr_clk)
    //--------------------------------------------------
    $display("---- WRITE START ----");

    repeat (5) begin
        @(posedge wr_clk);
        if (!full) begin
            wr_en = 1;
            data_in = $random % 256;
            $display("Time=%0t WRITE data=%h", $time, data_in);
        end
    end

    @(posedge wr_clk);
    wr_en = 0;

    //--------------------------------------------------
    // WAIT BEFORE READ
    //--------------------------------------------------
    #30;

    //--------------------------------------------------
    // READ OPERATION (SYNC WITH rd_clk)
    //--------------------------------------------------
    $display("---- READ START ----");

    repeat (5) begin
        @(posedge rd_clk);
        if (!empty) begin
            rd_en = 1;
            $display("Time=%0t READ data=%h", $time, data_out);
        end
    end

    @(posedge rd_clk);
    rd_en = 0;

    //--------------------------------------------------
    // FINISH
    //--------------------------------------------------
    #50;
    $display("---- SIMULATION END ----");
    $finish;
end

//--------------------------------------------------
// MONITOR (DEBUG)
//--------------------------------------------------
initial begin
    $monitor("Time=%0t wr_en=%b rd_en=%b full=%b empty=%b data_out=%h",
              $time, wr_en, rd_en, full, empty, data_out);
end

endmodule