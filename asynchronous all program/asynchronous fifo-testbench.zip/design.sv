// Code your design here
//======================================================
// ASYNC FIFO (TOP MODULE)
//======================================================
module async_fifo #(parameter DATA_WIDTH = 8,
                    parameter ADDR_WIDTH = 3)
(
    input wr_clk,
    input rd_clk,
    input wr_rst,
    input rd_rst,
    input wr_en,
    input rd_en,
    input [DATA_WIDTH-1:0] data_in,

    output reg [DATA_WIDTH-1:0] data_out,
    output full,
    output empty
);

// FIFO memory
reg [DATA_WIDTH-1:0] mem [0:(1<<ADDR_WIDTH)-1];

// Pointers
reg [ADDR_WIDTH:0] wr_bin, rd_bin;
reg [ADDR_WIDTH:0] wr_gray, rd_gray;

// Synchronizers
reg [ADDR_WIDTH:0] wr_gray_sync1, wr_gray_sync2;
reg [ADDR_WIDTH:0] rd_gray_sync1, rd_gray_sync2;

//------------------------------------------------------
// WRITE POINTER (Binary + Gray)
//------------------------------------------------------
always @(posedge wr_clk or posedge wr_rst) begin
    if (wr_rst) begin
        wr_bin  <= 0;
        wr_gray <= 0;
    end else if (wr_en && !full) begin
        wr_bin  <= wr_bin + 1;
        wr_gray <= (wr_bin + 1) ^ ((wr_bin + 1) >> 1);
    end
end

//------------------------------------------------------
// READ POINTER (Binary + Gray)
//------------------------------------------------------
always @(posedge rd_clk or posedge rd_rst) begin
    if (rd_rst) begin
        rd_bin  <= 0;
        rd_gray <= 0;
    end else if (rd_en && !empty) begin
        rd_bin  <= rd_bin + 1;
        rd_gray <= (rd_bin + 1) ^ ((rd_bin + 1) >> 1);
    end
end

//------------------------------------------------------
// MEMORY WRITE
//------------------------------------------------------
always @(posedge wr_clk) begin
    if (wr_en && !full)
        mem[wr_bin[ADDR_WIDTH-1:0]] <= data_in;
end

//------------------------------------------------------
// MEMORY READ
//------------------------------------------------------
always @(posedge rd_clk) begin
    if (rd_en && !empty)
        data_out <= mem[rd_bin[ADDR_WIDTH-1:0]];
end

//------------------------------------------------------
// SYNCHRONIZE POINTERS
//------------------------------------------------------

// Sync read pointer into write clock domain
always @(posedge wr_clk or posedge wr_rst) begin
    if (wr_rst) begin
        rd_gray_sync1 <= 0;
        rd_gray_sync2 <= 0;
    end else begin
        rd_gray_sync1 <= rd_gray;
        rd_gray_sync2 <= rd_gray_sync1;
    end
end

// Sync write pointer into read clock domain
always @(posedge rd_clk or posedge rd_rst) begin
    if (rd_rst) begin
        wr_gray_sync1 <= 0;
        wr_gray_sync2 <= 0;
    end else begin
        wr_gray_sync1 <= wr_gray;
        wr_gray_sync2 <= wr_gray_sync1;
    end
end

//------------------------------------------------------
// FULL CONDITION
//------------------------------------------------------
assign full = (wr_gray == {~rd_gray_sync2[ADDR_WIDTH:ADDR_WIDTH-1],
                          rd_gray_sync2[ADDR_WIDTH-2:0]});

//------------------------------------------------------
// EMPTY CONDITION
//------------------------------------------------------
assign empty = (rd_gray == wr_gray_sync2);

endmodule`timescale 1ns/1ps

module async_fifo_tb;

parameter DATA_WIDTH = 8;
parameter ADDR_WIDTH = 3;

// DUT signals
reg wr_clk, rd_clk;
reg wr_rst, rd_rst;
reg wr_en, rd_en;
reg [DATA_WIDTH-1:0] data_in;

wire [DATA_WIDTH-1:0] data_out;
wire full, empty;

// DUT instantiation
async_fifo #(DATA_WIDTH, ADDR_WIDTH) dut(
    .wr_clk(wr_clk),
    .rd_clk(rd_clk),
    .wr_rst(wr_rst),
    .rd_rst(rd_rst),
    .wr_en(wr_en),
    .rd_en(rd_en),
    .data_in(data_in),
    .data_out(data_out),
    .full(full),
    .empty(empty)
);

// Clock generation
always #5 wr_clk = ~wr_clk;   // 10ns period
always #7 rd_clk = ~rd_clk;   // 14ns period

// VCD dump
initial begin
    $dumpfile("async_fifo.vcd");
    $dumpvars(0, async_fifo_tb);
end

//--------------------------------------------------
// MAIN TEST
//--------------------------------------------------
initial begin
    // Initialize
    wr_clk = 0;
    rd_clk = 0;
    wr_rst = 1;
    rd_rst = 1;
    wr_en  = 0;
    rd_en  = 0;
    data_in = 0;

    // Apply reset
    #20;
    wr_rst = 0;
    rd_rst = 0;

    //--------------------------------------------------
    // WRITE OPERATION (SYNC WITH wr_clk)
    //--------------------------------------------------
    $display("---- WRITE START ----");

    repeat (5) begin
        @(posedge wr_clk);
        if (!full) begin
            wr_en = 1;
            data_in = $random % 256;
            $display("Time=%0t WRITE data=%h", $time, data_in);
        end
    end

    @(posedge wr_clk);
    wr_en = 0;

    //--------------------------------------------------
    // WAIT BEFORE READ
    //--------------------------------------------------
    #30;

    //--------------------------------------------------
    // READ OPERATION (SYNC WITH rd_clk)
    //--------------------------------------------------
    $display("---- READ START ----");

    repeat (5) begin
        @(posedge rd_clk);
        if (!empty) begin
            rd_en = 1;
            $display("Time=%0t READ data=%h", $time, data_out);
        end
    end

    @(posedge rd_clk);
    rd_en = 0;

    //--------------------------------------------------
    // FINISH
    //--------------------------------------------------
    #50;
    $display("---- SIMULATION END ----");
    $finish;
end

//--------------------------------------------------
// MONITOR (DEBUG)
//--------------------------------------------------
initial begin
    $monitor("Time=%0t wr_en=%b rd_en=%b full=%b empty=%b data_out=%h",
              $time, wr_en, rd_en, full, empty, data_out);
end

endmodule