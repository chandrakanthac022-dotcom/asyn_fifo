// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module read_pointer_tb;

parameter ADDR_WIDTH = 3;

reg rd_clk;
reg rd_rst;
reg rd_en;
reg [ADDR_WIDTH:0] wr_gray_sync;

wire [ADDR_WIDTH:0] rd_bin;
wire [ADDR_WIDTH:0] rd_gray;
wire empty;

// Instantiate DUT
read_pointer #(ADDR_WIDTH) dut (
    .rd_clk(rd_clk),
    .rd_rst(rd_rst),
    .rd_en(rd_en),
    .wr_gray_sync(wr_gray_sync),
    .rd_bin(rd_bin),
    .rd_gray(rd_gray),
    .empty(empty)
);

// Clock generation
always #5 rd_clk = ~rd_clk;

// Waveform dump
initial begin
$dumpfile("dump.vcd");
$dumpvars(0, read_pointer_tb);
end

initial begin

// Initialize signals
rd_clk = 0;
rd_rst = 1;
rd_en  = 0;
wr_gray_sync = 0;

// Reset release
#10 rd_rst = 0;

// Simulate data written into FIFO
#10 wr_gray_sync = 4'b0001;

// Enable reading
#10 rd_en = 1;

// Continue reading
#40;

// Stop reading
#10 rd_en = 0;

// End simulation
#50 $finish;
  
end

// Mo nitor signals
initial begin
$monitor("Time=%0t rd_en=%b empty=%b rd_bin=%b rd_gray=%b",
          $time, rd_en, empty, rd_bin, rd_gray);
end

endmodule