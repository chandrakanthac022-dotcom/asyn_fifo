// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module sync_pointer_tb;

parameter ADDR_WIDTH = 3;

reg clk;
reg rst;
reg [ADDR_WIDTH:0] ptr_in;

wire [ADDR_WIDTH:0] ptr_out;

sync_pointer #(ADDR_WIDTH) dut (
    .clk(clk),
    .rst(rst),
    .ptr_in(ptr_in),
    .ptr_out(ptr_out)
);

always #5 clk = ~clk;

initial begin
$dumpfile("sync.vcd");
$dumpvars(0,sync_pointer_tb);
end

initial begin

clk = 0;
rst = 1;
ptr_in = 0;

#10 rst = 0;

#10 ptr_in = 4'b0001;
#20 ptr_in = 4'b0011;
#20 ptr_in = 4'b0010;

#50 $finish;

end

endmodule