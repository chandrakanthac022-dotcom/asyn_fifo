// Code your design here
module sync_pointer #(
    parameter ADDR_WIDTH = 3
)(
    input  wire clk,
    input  wire rst,
    input  wire [ADDR_WIDTH:0] ptr_in,
    output reg  [ADDR_WIDTH:0] ptr_out
);

reg [ADDR_WIDTH:0] sync_ff;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        sync_ff <= 0;
        ptr_out <= 0;
    end
    else begin
        sync_ff <= ptr_in;   // first flip-flop
        ptr_out <= sync_ff;  // second flip-flop
    end
end

endmodule